#ACCOUNTS_URLS.PY
from django.urls import path, include
from accounts import views

urlpatterns = [
     path('', include('pages.urls')),
    path('pages/', include('pages.urls')),
    path('login/', include('pages.urls')),
     path('login/pages/', include('pages.urls')),
    path('signup/', views.signup, name='signup'),
    
    path('profile/', views.profile, name='profile'),
    #path('login/profile', views.profile, name='profile'),
    #path('profile/', views.profile, name='profile'),
    #path('account/login/pages', include('pages.urls')),
    ]