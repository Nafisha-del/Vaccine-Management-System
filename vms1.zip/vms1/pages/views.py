# Create your views here.
#Vaccine_VIEWS.PY
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404, reverse
from django.contrib import messages
from django.core.mail import send_mail
from vms.settings import EMAIL_HOST_USER
from django.core.mail import EmailMessage
import datetime
from django.forms import Form
from .models import UserAccount, Scheduleappoint, Vaccine, VaccineTrack
from .forms import MyForm, BookCreate
from django.contrib.auth.decorators import login_required
from .import forms
from pages.forms import RescheduleForm
from django.utils import timezone
from .forms import ProfileForm, RescheduleForm


# Create your views here.
#ADMIN
def adminvac(request):
    vaccines = Vaccine.objects.all()
    context = {
        'vaccines':vaccines
        }
    return render(request, 'adminvac.html', context)

def vaccine_delete(request, id):
    obj = get_object_or_404(Vaccine, id=id)
    if request.method=="POST":
        obj.delete()
        return redirect(reverse('vaclist'))
    context = {
        "object":obj
        }
    return render(request, 'deletevac.html', context)

def editvac(request, *args, **kwargs):
    context={}
    if request.method=='POST':
        if request.POST.get('vacName') and request.POST.get('disease') and request.POST.get('costing'):
            saverecord = Vaccine()
            saverecord.vacName= request.POST.get('vacName')
            saverecord.disease= request.POST.get('disease')
            saverecord.vactype= request.POST.get('vactype')
            saverecord.costing= request.POST.get('costing')
            saverecord.company= request.POST.get('company')
            saverecord.country= request.POST.get('country')
            saverecord.save()
            messages.success(request, 'Record Saved Sucessfully!')
        
    return render(request, 'editvac.html', context)

def adminuser(request):
    users = UserAccount.objects.all()
    context = {
        'users':users
        }
    return render(request, 'adminuser.html', context)

def user_delete(request, id):
    obj = get_object_or_404(UserAccount, id=id)
    if request.method=="POST":
        obj.delete()
        return redirect(reverse('base'))
    context = {
        "object":obj
        }
    send_mail(
          'Account Deleted',
          'Your VMS account has been deleted. For more info visit our website Vaccination Management System(http://127.0.0.1:8000/)' ,
           EMAIL_HOST_USER,
           [obj.email],
           fail_silently=False,
           )   
    return render(request, 'deleteuser.html', context)

def adminappoint(request):
    appoints = Scheduleappoint.objects.all()
    context = {
        'appoints':appoints
        }
    return render(request, 'adminappoint.html', context)

def appoint_delete(request, id):
    obj = get_object_or_404(Scheduleappoint, id=id)
    acc = get_object_or_404(UserAccount, id=id)
    if request.method=="POST":
        obj.delete()
        return redirect(reverse('base'))
    context = {
        "object":obj
        }
    send_mail(
          'Appointment Cancelled',
          'Your appointment has been cancelled. For more info visit our website.' ,
           EMAIL_HOST_USER,
           [acc.email],
           fail_silently=False,
           )
    return render(request, 'deleteappoint.html', context)

#VACCINE VIEWS
def vaccine(request, *args, **kwargs):
    context={}
    return render(request, 'vaccine.html', context)

def vaclist(request, *args, **kwargs):
    data = Vaccine.objects.all()
    context={
        'data': data
        }
    return render(request, 'vaclist.html', context)

def vacChart(request, *args, **kwargs):
    context={}
    return render(request, 'vacChart.html', context)

def schedule(request, *args, **kwargs):
    context={}
    return render(request, 'schedule.html', context)

#PROFILE VIEWS
def profile(request):
    data = UserAccount.objects.last()
    data_2 = Scheduleappoint.objects.last()
    context={
        'first_name': data.first_name,
        'last_name': data.last_name,
        'age': data.age,
        'mobile': data.mobile,
        'email': data.email,
        'address': data.address,
        'city': data.city,
        'street':  data.street,
        'postal': data.postal,
        'clinic':data_2.clinic,
        'date': data_2.date
        }
    send_mail(
          'Profile Update',
          'Profile information has been sucessfully updated!' ,
           EMAIL_HOST_USER,
           [data.email],
           fail_silently=False,
           )     
    return render(request, 'profile.html', context)

def form(request):
    context={}
    if request.method=='POST':
        if request.POST.get('first_name') and request.POST.get('last_name') and request.POST.get('age') and request.POST.get('email'):
            saverecord = UserAccount()
            saverecord.first_name= request.POST.get('first_name')
            saverecord.last_name= request.POST.get('last_name')
            saverecord.age= request.POST.get('age')
            saverecord.mobile= request.POST.get('mobile')
            saverecord.email= request.POST.get('email')
            saverecord.address= request.POST.get('address')
            saverecord.city= request.POST.get('city')
            saverecord.street= request.POST.get('street')
            saverecord.postal= request.POST.get('postal')
            saverecord.save()
            messages.success(request, 'Record Saved Sucessfully!')
        
    return render(request, 'userform.html', context)

def form_signup(request):
    context={}
    return render(request, 'form.html', context)

def vac_track(request):
    posts = VaccineTrack.objects.all()
    context={
        'posts':posts
        }
    return render(request, 'saved.html', context)


#APPOINTMENT VIEWS
def appointments(request, *args, **kwargs):
    data = Scheduleappoint.objects.last()
    today = datetime.datetime.now().date()
    context={
        "today" : today,
        'id': data.id,
    }
    return render(request, 'appointments.html', context)

def scheduleappoint(request, *args, **kwargs):
    data = UserAccount.objects.last()
    context={}
    if  request.method=='POST':
       if request.POST.get('city') and request.POST.get('clinic')  and request.POST.get('date') and request.POST.get('time'):
          saverecord = Scheduleappoint()
          saverecord.city= request.POST.get('city')
          saverecord.clinic= request.POST.get('clinic')
          saverecord.date= request.POST.get('date')
          saverecord.time= request.POST.get('time')
          saverecord.save()
          messages.success(request, 'Record Saved Sucessfully!')
          send_mail(
          'Appoinment',
          'Your appoinment has been scheduled successfully!' ,
           EMAIL_HOST_USER,
           [data.email],
           fail_silently=False,
           )     
                       
    return render(request, 'scheduleappoint.html', context)

def readappoint(request, *args, **kwargs):
    data = Scheduleappoint.objects.last()
    today = datetime.datetime.now().date()
    context={
        'id': data.id,
        'city': data.city,
        'clinic': data.clinic,
        'date': data.date,
        'time': data.time,
        "today" : today
        }
    return render(request, 'readappoint.html', context)

def reschedule(request, id):
    display = Scheduleappoint.objects.get(id=id)
    return render(request, 'reschedule.html', {'Scheduleappoint':display})

def update(request,id):
    updateappoint = Scheduleappoint.objects.get(id=id)
    form=RescheduleForm(request.POST, instance=updateappoint)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Appointment rescheduled successfully!")
        return render(request, 'reschedule.html', {'Scheduleappoint':updateappoint})
        #return HttpResponseRedirect(updateappoint.get_absolute_url())
        #else:
        #    form = RescheduleForm(instance=updateappoint)
        #    return HttpResponse("Didn't work")
    #else:
        #return render(request, 'reschedule.html', {'form':form})
        

#ABOUT US VIEWS
def aboutus(request, *args, **kwargs):
    context={}
    return render(request, 'aboutus.html', context)

def group(request, *args, **kwargs):
    context={}
    return render(request, 'groupmembers.html', context) 

def proinfo(request, *args, **kwargs):
    context={}
    return render(request, 'proinfo.html', context)

def help(request):
    context={}
    return render(request, 'help.html', context)

def index(request, *args, **kwargs):
    context={}
    return render(request, 'index.html', context)  

def base(request, *args, **kwargs):
    context={}
    return render(request, 'base.html', context)   

#COVID VIEWS
def covid(request, *args, **kwargs):
    context={}
    return render(request, 'covid.html', context)    

def symptom(request, *args, **kwargs):
    context={}
    return render(request, 'symptom.html', context)

def prevention(request, *args, **kwargs):
    context={}
    return render(request, 'prevention.html', context)  

def treatment(request, *args, **kwargs):
    context={}
    return render(request, 'treatment.html', context)   

#OTHERS
def subscribe(request, *args, **kwargs):
    sub = forms.Subscribe()
    if request.method == 'POST':
        sub = forms.Subscribe(request.POST)
        subject = 'Welcome to Vaccination Management System'
        message = 'Your account have been successfully saved!'
        url = "https://docs.djangoproject.com/en/3.2/ref/forms/fields/"
        recepient = str(sub['Email'].value())
        send_mail(subject, 
            message, EMAIL_HOST_USER, [recepient], fail_silently = False)
        return render(request, 'success.html', {'recepient': recepient})
    return render(request, 'index1.html', {'form':sub})

def contact(request, *args, **kwargs):
    sub = forms.Subscribe()
    sub1 = forms.Subscribe()
    data = UserAccount.objects.last()
    if request.method == 'POST':
        sub = forms.Subscribe(request.POST)
        subject = (data.first_name,data.last_name,data.email)
        message= str(sub['Message'].value())
        send_mail(subject, 
         message, EMAIL_HOST_USER , ['2018-3-60-075@std.ewubd.edu','2018-3-60-047@std.ewubd.edu','2018-3-60-032@std.ewubd.edu'],  fail_silently = False)
        return render(request, 'success.html', {'recepient': recepient})
    return render(request, 'contact.html', {'form':sub})


def index(request):
	shelf = Scheduleappoint.objects.all()
	return render(request, 'library.html', {'shelf': shelf})

def upload(request):
	upload = BookCreate()
	if request.method == 'POST':
		upload = BookCreate(request.POST, request.FILES)
		if upload.is_valid():
			upload.save()
			return redirect('index')
		else:
			return HttpResponse("""your form is wrong, reload on <a href = "{{ url : 'index'}}">reload</a>""")
	else:
		return render(request, 'upload_form.html', {'upload_form':upload})

def update_book(request, book_id):
	book_id = int(book_id)
	try:
		book_sel = Scheduleappoint.objects.get(id = book_id)
	except Scheduleappoint.DoesNotExist:
		return redirect('index')
	book_form = BookCreate(request.POST or None, instance = book_sel)
	if book_form.is_valid():
		book_form.save()
		return redirect('index')
	return render(request, 'upload_form.html', {'upload_form':book_form})

def delete_book(request, book_id):
	book_id = int(book_id)
	try:
		book_sel = Scheduleappoint.objects.get(id = book_id)
	except Scheduleappoint.DoesNotExist:
		return redirect('index')
	book_sel.delete()
	return redirect('index')




