from django import forms
from .models import UserAccount, Scheduleappoint

class ProfileForm(forms.Form):
    first_name = forms.CharField(label="First Name", max_length=100)
    last_name = forms.CharField(label="Last Name",max_length=100)
    age = forms.IntegerField(label="Age",min_value=0)
    mobile = forms.IntegerField(label="Mobile Number")
    email = forms.EmailField(label="Email ID",max_length=254)
    address = forms.CharField(label="Address",max_length=100)
    city = forms.CharField(label="City",max_length=25)
    street = forms.CharField(label="Enter Street Name",max_length=50)
    postal = forms.CharField(label="Enter Postal Code",max_length=20)
 
class MyForm(forms.ModelForm):
  class Meta:
    model = UserAccount
    fields = ["first_name", "last_name", "age", "email",]
    labels = {'first_name': "First Name", 'last_name': "Last Name", 'age': "age",
              'email': "Email",}


class Subscribe(forms.Form):
    Message = forms.CharField()
    def __str__(self):
        return self.Message

class RescheduleForm(forms.ModelForm):
    class Meta:
        model = Scheduleappoint
        fields = "__all__"

class BookCreate(forms.ModelForm):
  class Meta:
    model = Scheduleappoint
    fields = "__all__"

