from django.contrib import admin

# Register your models here.
from .models import UserAccount, Vaccine, Scheduleappoint, VaccineTrack

admin.site.register(UserAccount)
admin.site.register(Vaccine)
admin.site.register(VaccineTrack)
admin.site.register(Scheduleappoint)

admin.site.site_header = "Vaccine Management System"
