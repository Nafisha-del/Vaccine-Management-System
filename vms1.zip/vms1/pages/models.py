from django.db import models
from django.urls import reverse
import datetime
from django.utils import timezone
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy

# Create your models here.
class Vaccine(models.Model):
    VACCINE_TYPE = (
        ('1', 'Government Vaccine'),
        ('2', 'Non-Government Vaccine')
        )
    vacName = models.CharField(max_length=200)
    disease = models.CharField(max_length=200, default='n/a')
    vactype = models.CharField(max_length=25, choices = VACCINE_TYPE, default='1')
    costing = models.IntegerField(default=0)
    company = models.CharField(max_length=200, default='n/a')
    country = models.CharField(max_length=200, default='n/a')

    def __str__(self):
        """String for representing the Model object."""
        return str(self.vacName)

    def get_absolute_url(self):
        """Returns the url to access a detail record for this book."""
        return reverse('vaclist')

class UserAccount(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    age = models.IntegerField()
    mobile = models.IntegerField(default=0)
    email = models.EmailField(max_length=254, default='n/a')
    address = models.CharField(max_length=100, default='n/a')
    city = models.CharField(max_length=25, default='n/a')
    street = models.CharField(max_length=50, default='n/a')
    postal = models.CharField(max_length=20, default='n/a')

    def __str__(self):
        """String for representing the Model object."""
        return str(self.first_name)

    class Meta:
        db_table ="useraccount"

     
class Scheduleappoint(models.Model):
    CLINIC_NAME = (
        ('Dhaka Community Hospital', 'Dhaka Community Hospital'),
        ('Japan East West Medical College Hospital, Dhaka', 'Japan East West Medical College Hospital, Dhaka'),
        ('Evercare Hospital, Dhaka', 'Evercare Hospital, Dhaka'),
        ('Chittagong Poly Clinic','Chittagong Poly Clinic'),
        ('Royal Hospital Chitagong','Royal Hospital Chitagong'),
        ('Ambia Memorial Hospital Barishal','Ambia Memorial Hospital Barishal')
        
    )
    DIVISION = (
           ('Dhaka','Dhaka (ঢাকা)'),
           ('Barishal','Barishal (বরিশাল )'),
           ('Chittagong','Chittagong (চট্টগ্রাম)'),
           ('Mymensingh','Mymensingh (ময়মনসিংহ)'),
           ('Khulna','Khulna (খুলনা )'),
           ('Rajshahi','Rajshahi (রাজশাহী)'),
           ('Rangpur','Rangpur (রংপুর )'),
           ('Sylhet','Sylhet (সিলেট )'),
    )
    TIME = (
        ('Morning', 'Morning'),
        ('Evening', 'Evening')
        )
    city = models.CharField(max_length=100, choices=DIVISION)
    clinic = models.CharField(max_length=100, choices=CLINIC_NAME)
    date = models.DateField(default=datetime.date.today)
    time = models.CharField(max_length=100, default='n/a', choices=TIME)

    def __str__(self):
        """String for representing the Model object."""
        return str(self.date)

    def get_absolute_url(self):
        return reverse("appointment", kwargs={"id":self.id})
    

    class Meta:
        db_table ="scheduleappoint" 



class VaccineTrack(models.Model):
    username = models.ForeignKey(UserAccount, db_column="first_name", on_delete=models.CASCADE)
    vaccine_name = models.ForeignKey(Vaccine, db_column="vacName", on_delete=models.CASCADE)
    date_administered = models.DateField(Scheduleappoint, db_column="date")

    def __str__(self):
        """String for representing the Model object."""
        return str(self.username)

    class Meta:
        ordering = ['vaccine_name']






