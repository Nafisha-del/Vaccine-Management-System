from django.urls import path, include
from pages import views

urlpatterns = [
    #ADMIN
    path('adminvac', views.adminvac, name='adminvac'),
    path('pages/<int:id>/', views.vaccine_delete, name='vaccine_delete'),
    path('editvac', views.editvac, name='editvac'),
    path('adminuser', views.adminuser, name='adminuser'),
    path('pages/<int:id>/deleteuser/', views.user_delete, name='user_delete'),
    path('adminappoint', views.adminappoint, name='adminappoint'),
    path('pages/<int:id>/deleteappoint/', views.appoint_delete, name='appoint_delete'),
    #VACCINE
    path('vaccine', views.vaccine, name='vaccine'),
    path('vaclist', views.vaclist, name='vaclist'),
    path('vacChart', views.vacChart, name='vacChart'),
    path('schedule', views.schedule, name='schedule'),
    #PROFILE
    path('form_signup', views.form_signup, name='form_signup'),
    path('userform/', views.form, name='form'),
    path('profile/', views.profile, name='profile'),
    #APPOINTMENT
    path('appointments', views.appointments, name='appointments'),
    path('scheduleappoint', views.scheduleappoint, name='scheduleappoint'),
    path('readappoint', views.readappoint, name='readappoint'),
    path('reschedule/<int:id>', views.reschedule, name='reschedule'),
    path('reschedule',views.help),
    path('update/<int:id>', views.update),
    #ABOUT US
    path('aboutus',views.aboutus, name='aboutus'),
    path('groupmembers', views.group, name='members'),
    path('proinfo', views.proinfo, name='proinfo'),
    #COVID
    path('covid', views.covid, name = 'covid'),
    path('symptom', views.symptom, name = 'symptom'),
    path('prevention', views.prevention, name = 'prevention'),
    path('treatment', views.treatment, name = 'treatment'), 
    #OTHERS
    path('saved',views.vac_track, name='vaccine_track'),
    path('help', views.help, name='help'),
    path('contact', views.contact, name='contact'),
    path('index', views.index, name='index'),
    path('base', views.base, name='base'),
    path('index1', views.subscribe, name='subscribe'),
    path('', views.index, name = 'index'),
	path('upload_form', views.upload, name = 'upload_form'),
	path('update/<int:book_id>', views.update_book),
	path('delete/<int:book_id>', views.delete_book)
    ]